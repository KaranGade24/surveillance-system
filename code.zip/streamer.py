import os
import json
# Added make_response to the imports below
from flask import jsonify, send_from_directory, make_response

DATA_DIR = "surveillance_data"

def get_directory_tree(path):
    """Recursively builds a JSON tree of the surveillance folders."""
    tree = {"name": os.path.basename(path), "type": "folder", "children": []}
    
    if not os.path.exists(path):
        return tree

    try:
        items = sorted(os.listdir(path), reverse=True) 
        
        for item in items:
            full_path = os.path.join(path, item)
            
            if os.path.isdir(full_path):
                tree["children"].append(get_directory_tree(full_path))
            elif item.endswith(".mp4"):
                rel_path = os.path.relpath(full_path, DATA_DIR).replace("\\", "/")
                tree["children"].append({
                    "name": item,
                    "type": "video",
                    "url": f"/api/stream/{rel_path}"
                })
    except Exception as e:
        print(f"⚠️ Error building directory tree: {e}")
        
    return tree

def register_streamer_routes(app):
    """Attaches all the archive API routes to your main Flask app."""
    
    @app.route('/api/archive/tree', methods=['GET'])
    def get_archive_tree():
        return jsonify(get_directory_tree(DATA_DIR))

    @app.route('/api/metadata/<path:subpath>', methods=['GET'])
    def get_video_metadata(subpath):
        video_dir = os.path.dirname(os.path.join(DATA_DIR, subpath))
        video_filename = os.path.basename(subpath)
        metadata_path = os.path.join(video_dir, "metadata.json")

        if not os.path.exists(metadata_path):
            return jsonify([]) 

        try:
            with open(metadata_path, 'r') as f:
                all_logs = json.load(f)
                video_logs = [log for log in all_logs if log.get("video_file") == video_filename]
                return jsonify(video_logs)
        except Exception as e:
            return jsonify({"error": str(e)}), 500




    @app.route('/api/stream/<path:filename>')
    def stream_video(filename):
        file_path = os.path.join(DATA_DIR, filename)
        if not os.path.exists(file_path):
            return "Video not found", 404

        # Use Flask's built-in helper but wrap it to add critical headers
        response = make_response(send_from_directory(DATA_DIR, filename))
        
        # 1. Force the MIME type so Firefox knows it's an MP4
        response.headers['Content-Type'] = 'video/mp4'
        
        # 2. Allow "Range" requests (Status 206) for seeking
        response.headers['Accept-Ranges'] = 'bytes'
        
        # 3. Prevent the browser from "sniffing" the type and getting confused
        response.headers['X-Content-Type-Options'] = 'nosniff'
        
        return response








