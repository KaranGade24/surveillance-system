import cv2
import os
import json
from datetime import datetime

class VideoRecorder:
    def __init__(self, base_dir="surveillance_data", fps=10.0):
        self.base_dir = base_dir
        self.fps = float(fps)
        self.out = None
        self.current_path = ""
        self.json_path = ""
        self.current_hour = -1
        
        os.makedirs(self.base_dir, exist_ok=True)

    def _get_paths(self):
        """Generates folder structure: surveillance_data/YYYY-MM-DD/HH-00/"""
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        hour_str = now.strftime("%H-00")
        
        directory = os.path.join(self.base_dir, date_str, hour_str)
        os.makedirs(directory, exist_ok=True)
            
        filename = f"video_{now.strftime('%H-%M-%S')}.mp4"
        self.current_path = os.path.join(directory, filename)
        self.json_path = os.path.join(directory, "metadata.json")
        self.current_hour = now.hour

    def start_new_video(self, frame_size):
        """Closes old video and starts a fresh one with correct dimensions"""
        self.stop() 
        self._get_paths()
        
        # 'mp4v' is highly efficient and compatible with low RAM systems
        fourcc = cv2.VideoWriter_fourcc(*'mp4v') 
        self.out = cv2.VideoWriter(self.current_path, fourcc, self.fps, frame_size)
        
        if not self.out.isOpened():
            print(f"❌ ERROR: Could not open VideoWriter for {self.current_path}")
        else:
            print(f"📁 Recording started: {self.current_path} at {self.fps} FPS")

    def write_frame(self, frame, has_fire, detections=None):
        """Writes frame to disk. Automatically rotates file if hour changes."""
        now_hour = datetime.now().hour
        
        if self.out is None or now_hour != self.current_hour:
            h, w = frame.shape[:2]
            self.start_new_video((w, h))

        if self.out:
            self.out.write(frame)

        if has_fire and detections:
            self.log_detection(detections)

    def log_detection(self, detections):
        """Appends detection info to JSON."""
        log_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "video_file": os.path.basename(self.current_path),
            "detections": detections
        }
        
        data = []
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, 'r') as f:
                    content = f.read().strip()
                    if content:
                        data = json.loads(content)
                        if not isinstance(data, list): data = []
            except Exception:
                data = []
        
        data.append(log_entry)
        
        try:
            with open(self.json_path, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"⚠️ Metadata Log Error: {e}")

    def stop(self):
        """Safely closes the video file"""
        if self.out:
            self.out.release()
            self.out = None
            print(f"💾 Video segment saved: {self.current_path}")

    def __del__(self):
        self.stop()





























